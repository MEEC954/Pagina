console.log('MarketCat (https://push.marketcat.net/): Bot usage has been detected, pixel stopped from executing.')
;
console.log('MarketCat (https://widgets.marketcat.net/): Bot usage has been detected, pixel stopped from executing.')
;